package hello; 

public class HelloGoodBye{
    public static void main(String[] args){
        System.out.println("Hello GoodBye");
    }
}